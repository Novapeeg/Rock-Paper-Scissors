import random
import sys

print("______           _     ______                       _____      _                        ")
print("| ___ \         | |    | ___ \                     /  ___|    (_)                       ")
print("| |_/ /___   ___| | __ | |_/ /_ _ _ __   ___ _ __  \ `--.  ___ _ ___ ___  ___  _ __ ___ ")
print("|    // _ \ / __| |/ / |  __/ _` | '_ \ / _ \ '__|  `--. \/ __| / __/ __|/ _ \| '__/ __|")
print("| |\ \ (_) | (__|   <  | | | (_| | |_) |  __/ |    /\__/ / (__| \__ \__ \ (_) | |  \__ \ ")
print("\_| \_\___/ \___|_|\_\ \_|  \__,_| .__/ \___|_|    \____/ \___|_|___/___/\___/|_|  |___/")
print("                                 |_|                                                    ")

print("Created by Justin Wilmot aka Novapeeg")
print("  ")
print("rock=1")
print("paper=2")
print("scissors=3")

def rps():
  print("  ")
  player1=input("enter rock(1), paper(2) or scissors(3):")

  computer=random.randint(1,3)
  print("computer put down:")
  if (computer==1):
    print("Rock")
  elif (computer==2):
    print("Paper")
  elif (computer==3):
    print("Scissors")


  if (computer==1 and int(player1)==2):
    print("Paper covers rock. You win!")
  elif (computer==1 and int(player1)==3):
    print("Rock crushes scissors. You lose!")
  elif (computer==2 and int(player1)==1):
    print("Paper covers rock. You lose!")
  elif (computer==2 and int(player1)==3):
    print("Scissors cuts paper. You win!")
  elif (computer==3 and int(player1)==1):
    print("Rock crushes scissors. You win!")
  elif (computer==3 and int(player1)==2):
    print("Scissors cuts paper. You lose!")
  else:
    print("You both chose the same hand. Tie!")



rps()

again = str(input("Do you want to play again (type yes or no): "))
while(again == "yes"):
   rps()
   again = str(input("Do you want to play again (type yes or no): "))
else:
   print("  ")
   print("Thanks for playing!")
   sys.exit
